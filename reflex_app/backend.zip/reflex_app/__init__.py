"""Aero Crew Data Analyzer - Reflex Edition."""

from .reflex_app import app

__all__ = ["app"]
